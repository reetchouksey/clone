import card_img1 from "./image_1.jpg";
import card_img2 from "./image_2.jpg";
import card_img3 from "./image_3.jpg";
import card_img4 from "./image_4.jpg";
import card_img5 from "./image_5.jpg";
import card_img6 from "./image_6.jpg";
import card_img7 from "./image_7.jpg";
import card_img8 from "./image_8.jpg";
import card_img9 from "./image_9.jpg";
import card_img10 from "./image_10.jpg";
import card_img11 from "./image_11.jpg";
import card_img12 from "./image_12.jpg";
import card_img13 from "./image_13.jpg";
import card_img14 from "./image_14.jpg";
import card_img15 from "./image_15.jpg";

const cards_data = [
  { img: card_img1, name: "glass onion" },

  { img: card_img2, name: "carry on" },

  { img: card_img3, name: "the gray man" },

  { img: card_img4, name: "lucky buskha" },

  { img: card_img5, name: "maharaj" },

  { img: card_img6, name: "doctor" },

  { img: card_img7, name: "28 years later" },

  { img: card_img8, name: "squid game" },

  { img: card_img9, name: "mario bross" },

  { img: card_img10, name: "over the moon" },

  { img: card_img11, name: "the life list" },

  { img: card_img12, name: "saiyaara" },

  { img: card_img13, name: "american" },

  { img: card_img14, name: "narstmha" },

  { img: card_img15, name: "breadwinner" },
];

export default cards_data;
