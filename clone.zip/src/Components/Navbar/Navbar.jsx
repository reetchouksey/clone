// import React, { useEffect, useRef } from "react";
// import "./Navbar.css";
// import "../../Pages/Login/Login.css";

// import  logo from "../../assets/nlogo.png";
// import search from "../../assets/searchicon.jpg";
// import bell from "../../assets/bell.jpg";
// import player from "../../assets/player.jpg";
// import dropdown from "../../assets/dropdown.jpg";
// const Navbar = () => {

//   const navRef = useRef();
//   useEffect (()=>{ window.addEventListener("scroll",()=>{
//     if (window.screeny>=80){
//       navRef.current.classList.add('nav-dark')
//     } else {
//       navRef.current.classList.remove('nav-dark')
//     }
//   }},{}))
  
//   return (
//     <div  ref=(navRef) className="navbar">
//       <div className="navbar-left">
//         <img className="logo" src={logo} alt="" />
//         <ul>
//           <li>
//             <b>Home</b>
//           </li>
//           <li>
//             <b>Tv Shows</b>
//           </li>
//           <li>
//             <b>Movies</b>
//           </li>
//           <li>
//             <b>New & Popular</b>
//           </li>
//           <li>
//             <b>My List</b>
//           </li>
//           <li>
//             <b>Browse By Languages</b>
//           </li>
//         </ul>
//       </div>
//       <div className="navbar-right">
//         <img src={search} alt="" className="icons" />
//         <p>
//           <b>Children</b>
//         </p>
//         <img src={bell} alt="" className="icons" />
//         <div className="navbar-profile">
//           <img src={player} alt="" className="profile" />
//           <img src={dropdown} alt="" className="pro" />
//           <div className="dropdown">
//             <p>Sign Out Of Netflix</p>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Navbar;



import React, { useEffect, useRef } from "react";
import "./Navbar.css";
import "../../Pages/Login/Login.css";

import logo from "../../assets/nlogo.png";
import search from "../../assets/searchicon.jpg";
import bell from "../../assets/bell.jpg";
import player from "../../assets/player.jpg";
import dropdown from "../../assets/dropdown.jpg";
 import { logout } from "../../Firebase";


const Navbar = () => {
  const navRef = useRef(null);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY >= 80) {
        navRef.current.classList.add("nav-dark");
      } else {
        // navRef.current.classList.remove("nav-dark");
      }
    };

    window.addEventListener("scroll", handleScroll);

   
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return (
    <div ref={navRef} className="navbar">

      <div className="navbar-left">
        <img className="logo" src={logo} alt="Netflix Logo" />
        <ul>
          <li><b>Home</b></li>
          <li><b>TV Shows</b></li>
          <li><b>Movies</b></li>
          <li><b>New & Popular</b></li>
          <li><b>My List</b></li>
          <li><b>Browse by Languages</b></li>
        </ul>
      </div>

      <div className="navbar-right">
        <img src={search} alt="Search Icon" className="icons" />
        <p><b>Children</b></p>
        <img src={bell} alt="Notification Icon" className="icons" />

        <div className="navbar-profile">
          <img src={player} alt="User Profile" className="profile" />
          <img src={dropdown} alt="Dropdown Icon" className="pro" />
          <div className="dropdown">
            <p onClick={()=>{logout()}}>Sign Out of Netflix</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Navbar;
